# Integrate the supplied Brand Identity Tour & Travel image pack

Use the supplied image pack in the existing `shahnaveed07/tourandtravels` React + Vite + JavaScript/JSX repository.

1. Copy `public/images/` into the repository's `public/images/` and copy `src/imageCatalog.js` into `src/`.
2. Read `IMAGE-IMPLEMENTATION-GUIDE.md` and `IMAGE-MANIFEST.csv` first. Use the provided semantic catalog rather than guessing filenames.
3. Update all image assignments in `src/data.js` for all six destinations, all eight tour packages, and the three travel guides using `siteImages`.
4. Update hard-coded image `src` values in `src/pages/Home.jsx` (hero, moments, and any other hard-coded marketing photos) and `src/pages/About.jsx`. Search every JSX file for remaining Unsplash URLs and replace only those that correspond to these uploaded photos.
5. Use the horizontal logo and emblem carefully; do not break the existing responsive header. If the existing text wordmark is cleaner/readable at small sizes, keep it and use the logo on About/Footer instead.
6. Distribute the company/office, Kashmir culture, local products, scenic, and accommodation photos in the appropriate current page sections. Avoid adding a large unstructured gallery or repeating the same image across many cards.
7. Preserve each image's aspect ratio with `object-fit: cover` for cards and `contain` for logo images. Add meaningful `alt` text and lazy loading below the fold. Keep the hero eager/high priority.
8. Preserve the current theme, layout, routes, filters, enquiry links, and all existing functionality. Do not add a backend or extra network/API dependency.
9. Do not remove embedded original branding/watermarks from the image pixels, and do not claim pictured hotels/resorts/products are owned or available unless verified.
10. Ensure assets resolve on both local Vite and GitHub Pages. Use `siteImages` paths based on `import.meta.env.BASE_URL`; do not hardcode root-relative `/images/...` paths.
11. Search the whole project for `images.unsplash.com` and replace intended visitor-facing placeholders. Keep intentional exceptions only when an uploaded asset genuinely does not match.
12. Run `npm ci`, `npm run build`, and `npm test`; fix errors. Check the Home, Packages, destinations, package details, About and guide pages on phone and desktop.
13. Report each updated page, the number of image URLs replaced, any remaining external image URLs and why they remain, and test results.

Make the actual code changes in the repository. Do not merely write another prompt or stop after copying the files.
