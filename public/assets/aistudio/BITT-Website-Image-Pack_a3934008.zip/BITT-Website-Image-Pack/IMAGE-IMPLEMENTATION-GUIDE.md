# Brand Identity Tour & Travel — Website Image Pack

This pack contains optimized local WebP assets made from the supplied `BITTimages.zip` archive.

## Contents

- `public/images/` — 50 unique WebP images ready for the Vite site's public directory.
- `src/imageCatalog.js` — centralized, GitHub-Pages-aware image paths and suggested semantic assignments.
- `IMAGE-MANIFEST.csv` — original uploaded filename, output filename, image category, alt text, dimensions, and optimized size.

The upload contained 51 files. `IMG-20261109-WA0055.jpg` and `IMG-20261109-WA0055(1).jpg` are byte-identical, so they share one WebP output instead of adding a duplicate to the website.

## Install into the repository

Copy the `public/images/` folder into the repository's existing `public/` folder. Copy `src/imageCatalog.js` into `src/`.

Then wire the catalog into the existing components:

1. In `src/data.js`, import `{ siteImages } from './imageCatalog.js'`.
2. Replace destination image URLs using `siteImages.destinations`:
   - Srinagar → `siteImages.destinations.srinagar`
   - Gulmarg → `siteImages.destinations.gulmarg`
   - Pahalgam → `siteImages.destinations.pahalgam`
   - Sonamarg → `siteImages.destinations.sonamarg`
   - Gurez Valley → `siteImages.destinations.gurezValley`
   - Doodhpathri → `siteImages.destinations.doodhpathri`
3. Replace package image URLs using the matching `siteImages.packages` keys.
4. Replace the three guide images using `siteImages.guides`.
5. In `src/pages/Home.jsx`, replace the hard-coded hero image with `siteImages.hero`, and use `siteImages.homeMoments` for travel-moment cards.
6. In `src/pages/About.jsx`, use `siteImages.company.storefront` or `siteImages.company.office` for the story image. Use the company photos for a small real-company gallery if the page needs it.
7. Use `siteImages.culture`, `siteImages.stays`, and `siteImages.gallery` for existing gallery/experience slots or a compact photo gallery section. Do not add all 50 images as a huge unstructured wall; organize the content into relevant sections.
8. For logos, use the horizontal logo in header/footer and the emblem for compact placements only if it remains legible at the rendered size. Preserve the current typography if the logo does not fit.

Example:

```jsx
import { siteImages } from '../imageCatalog.js';

<img src={siteImages.hero} alt="Green Kashmir valley with mountain scenery" />
```

The catalog prefixes assets with `import.meta.env.BASE_URL`, so the paths work both locally and under the GitHub Pages subpath. Do not hardcode `/images/...` in React components.

## Important image notes

- Several supplied promotional photos contain baked-in text and the `bittkashmir.in` watermark. These are part of the original image pixels, not HTML overlays. They have been preserved rather than altered.
- The logo files have white backgrounds. They are not transparent PNG/SVG logos; use them on a suitable light surface and check header sizing before replacing the current wordmark.
- Keep meaningful alt text; use empty alt text only for purely decorative images.
- Do not use a resort image as evidence that the company owns or operates that property. Treat those images as travel inspiration / accommodation imagery unless ownership is confirmed.
- Do not present sample hotels, dining scenes, or products as confirmed inventory or inclusions unless the business has verified them.

## Verify after integration

Run:

```bash
npm ci
npm run build
npm test
```

Then inspect Home, Packages, each destination, Package Detail, About, and Travel Guide pages at desktop and mobile widths. Confirm there are no remaining Unsplash image URLs in the visitor-facing image slots unless intentionally retained.
